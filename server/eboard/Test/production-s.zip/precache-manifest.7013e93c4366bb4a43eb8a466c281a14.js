self.__precacheManifest = [
  {
    "revision": "cc06e2aac7d29bcb6151a0f6025abd23",
    "url": "/fonts/weather-icons/sass/weather-icons.scss"
  },
  {
    "revision": "9b1f95fc5da5fd24dbb55e82bf309bd5",
    "url": "/fonts/weather-icons/_builder/wbuilder"
  },
  {
    "revision": "3d7f1656ecd762e9d1370d8d3124d67c",
    "url": "/fonts/weather-icons/_docs/font-source/artwork/cloud pieces.ai"
  },
  {
    "revision": "50a51685f7fd398d5cbe",
    "url": "/js/app.dc3001ce.js"
  },
  {
    "revision": "44ce106bc4d225f3f5d0039e55ebb345",
    "url": "/fonts/weather-icons/_docs/font-source/artwork/tsunami.ai"
  },
  {
    "revision": "eb7e3877bf99d7a7d607",
    "url": "/js/chunk-vendors.5816cf7b.js"
  },
  {
    "revision": "a569ee37357987714b9f6138f30da236",
    "url": "/fonts/weather-icons/_docs/font-source/artwork/icon template.ai"
  },
  {
    "revision": "2178477db305d7101f8adb49cf52bff0",
    "url": "/img/01.jpeg"
  },
  {
    "revision": "b355360fc3b20cd0d5aaffea35afc440",
    "url": "/fonts/weather-icons/_docs/font-source/weathericons-regular.glyphs"
  },
  {
    "revision": "df02dec5f3655c8300ab215bb70195ec",
    "url": "/fonts/weather-icons/_docs/gh-pages/css/img/sky.jpg"
  },
  {
    "revision": "3a92e7312654c4f0c34638654b4187d9",
    "url": "/index.html"
  },
  {
    "revision": "76a4f23c6be74fd309e0d0fd2c27a5de",
    "url": "/fonts/weather-icons/_docs/gh-pages/fonts/fontawesome-webfont.svg"
  },
  {
    "revision": "ecaf8b481729b18f6a8494d9f691cdae",
    "url": "/fonts/weather-icons/font/weathericons-regular-webfont.svg"
  },
  {
    "revision": "207c5b871f760c15b81758a290deed99",
    "url": "/fonts/weather-icons/values/weathericons.xml"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  },
  {
    "revision": "56e49cd3e26af14007a5642cd119e0aa",
    "url": "/fonts/weather-icons/svg/wi-windy.svg"
  },
  {
    "revision": "155d0f5869574ca3355d156cddf74be5",
    "url": "/fonts/weather-icons/svg/wi-wind-deg.svg"
  },
  {
    "revision": "0cace54932788d3775eff5a9858072e1",
    "url": "/fonts/weather-icons/svg/wi-wind-beaufort-9.svg"
  },
  {
    "revision": "6b4f833db9e039193a12f0b48b8b0fc7",
    "url": "/fonts/weather-icons/svg/wi-wind-beaufort-8.svg"
  },
  {
    "revision": "3b54651965b657ce8b56f04082a3e0c5",
    "url": "/fonts/weather-icons/svg/wi-wind-beaufort-7.svg"
  },
  {
    "revision": "cab0f775368f0b771d9853851924a079",
    "url": "/fonts/weather-icons/svg/wi-wind-beaufort-6.svg"
  },
  {
    "revision": "e999d1c88dba2ca3bb7a1be4bbebbefd",
    "url": "/fonts/weather-icons/svg/wi-wind-beaufort-5.svg"
  },
  {
    "revision": "8203e0dc64bb4b5799792afcdd2d06cc",
    "url": "/fonts/weather-icons/svg/wi-wind-beaufort-4.svg"
  },
  {
    "revision": "9582fbe88f2469bd91b64e52f0e06cff",
    "url": "/fonts/weather-icons/svg/wi-wind-beaufort-3.svg"
  },
  {
    "revision": "d9ddbb84964292614592f2b156b19319",
    "url": "/fonts/weather-icons/svg/wi-wind-beaufort-2.svg"
  },
  {
    "revision": "85682cb6753a9d51f3ca9f9cce550cc0",
    "url": "/fonts/weather-icons/svg/wi-wind-beaufort-12.svg"
  },
  {
    "revision": "71f1d75a36bb080f8c39929815533e53",
    "url": "/fonts/weather-icons/css/weather-icons-wind.css"
  },
  {
    "revision": "bfd0311099f968b7ba783b772ed69e5d",
    "url": "/fonts/weather-icons/svg/wi-wind-beaufort-11.svg"
  },
  {
    "revision": "d979f0a82fa554458e13db0ec6b3ec83",
    "url": "/fonts/weather-icons/svg/wi-wind-beaufort-10.svg"
  },
  {
    "revision": "e8c53992b83b0bc80f7972b543ae9c6e",
    "url": "/fonts/weather-icons/svg/wi-wind-beaufort-1.svg"
  },
  {
    "revision": "e91b37f72a9ab1e9db06130e83f932b4",
    "url": "/fonts/weather-icons/svg/wi-wind-beaufort-0.svg"
  },
  {
    "revision": "a826f29be86a6273d3c1796afd895a44",
    "url": "/fonts/weather-icons/svg/wi-volcano.svg"
  },
  {
    "revision": "e0979da9779be926c4042a1d91ddb046",
    "url": "/fonts/weather-icons/svg/wi-umbrella.svg"
  },
  {
    "revision": "0e8f7700b2660fa19354741f960b9d12",
    "url": "/fonts/weather-icons/svg/wi-tsunami.svg"
  },
  {
    "revision": "129c7f6cd10c0eb3802e63323b9513fb",
    "url": "/fonts/weather-icons/_builder/wind-degrees.edn"
  },
  {
    "revision": "0a46cafe5a1ea6d84f7e774eb5905831",
    "url": "/fonts/weather-icons/_builder/wind.edn"
  },
  {
    "revision": "389a56b36ae5118f7529f336e998867c",
    "url": "/fonts/weather-icons/_docs/gh-pages/browserconfig.xml"
  },
  {
    "revision": "319cd16081472431e59ca876bec76524",
    "url": "/fonts/weather-icons/_docs/gh-pages/CNAME"
  },
  {
    "revision": "2b9c94dfe9f391a28bf555545ca8dd6b",
    "url": "/fonts/weather-icons/_docs/gh-pages/favicons/apple-touch-icon.png"
  },
  {
    "revision": "71d9289879334df4f9f6003791a4c27e",
    "url": "/fonts/weather-icons/_docs/gh-pages/favicons/apple-touch-icon-57x57.png"
  },
  {
    "revision": "2607b1a4d3711f86cda7dee4666f29be",
    "url": "/fonts/weather-icons/_docs/gh-pages/favicons/apple-touch-icon-precomposed.png"
  },
  {
    "revision": "640566320cc4a2306999499eaf97939e",
    "url": "/fonts/weather-icons/_docs/gh-pages/favicons/favicon-16x16.png"
  },
  {
    "revision": "37af7653fc263519ee97522d108307c1",
    "url": "/fonts/weather-icons/_docs/gh-pages/favicons/favicon-32x32.png"
  },
  {
    "revision": "4e86731843b3d36b1e8141d30b561707",
    "url": "/fonts/weather-icons/_docs/gh-pages/favicons/mstile-150x150.png"
  },
  {
    "revision": "dff18b5d72d93a04cf3d5411d0850894",
    "url": "/fonts/weather-icons/_docs/gh-pages/favicons/mstile-310x150.png"
  },
  {
    "revision": "10d325a8b35006d373233459b406d790",
    "url": "/fonts/weather-icons/_docs/gh-pages/favicons/mstile-70x70.png"
  },
  {
    "revision": "2472afa2e4e1b21144d7d77a6f57c950",
    "url": "/fonts/weather-icons/_docs/jade/icon-list-beaufort.jade"
  },
  {
    "revision": "51be82eb2afcf35a925a9de550b29ac8",
    "url": "/fonts/weather-icons/_docs/jade/icon-list-direction.jade"
  },
  {
    "revision": "3d2915c3fb8de298bbce7dddbde08c4f",
    "url": "/fonts/weather-icons/_docs/jade/icon-list-day.jade"
  },
  {
    "revision": "80e051bb28cc9c14809b56f7864bd081",
    "url": "/fonts/weather-icons/_docs/jade/icon-list-misc.jade"
  },
  {
    "revision": "dbae5eead518456791756bfd9401b1e6",
    "url": "/fonts/weather-icons/_docs/jade/icon-list-moon.jade"
  },
  {
    "revision": "f0682b43691b0e41bc67f223c33b9d98",
    "url": "/fonts/weather-icons/_docs/jade/icon-list-neutral.jade"
  },
  {
    "revision": "1543adc7b8e2dbfa1928e73972ae1728",
    "url": "/fonts/weather-icons/_docs/jade/icon-list-night.jade"
  },
  {
    "revision": "25e452bec370eb3c6c725cf97bb7c1e7",
    "url": "/fonts/weather-icons/_docs/jade/icon-list-time.jade"
  },
  {
    "revision": "2b9c94dfe9f391a28bf555545ca8dd6b",
    "url": "/fonts/weather-icons/_docs/gh-pages/favicons/apple-touch-icon-60x60.png"
  },
  {
    "revision": "8388b27629d2c43064de0bf7b2ad0a59",
    "url": "/fonts/weather-icons/_docs/jade/icon-list-wind-cardinal.jade"
  },
  {
    "revision": "aeeda91f5e9d33a11ec062622692090e",
    "url": "/fonts/weather-icons/_docs/jade/icon-list-wind.jade"
  },
  {
    "revision": "3e83ed8aa3f4dc9adcc7ef60b33edc29",
    "url": "/fonts/weather-icons/_docs/jade/icon-list.jade"
  },
  {
    "revision": "a8326f6335eb2dd1a13a3c5c58b90993",
    "url": "/fonts/weather-icons/_docs/jade/new-icons.jade"
  },
  {
    "revision": "76297af051f232b910e73aa1d6e81ec5",
    "url": "/fonts/weather-icons/_docs/less/bootstrap-includes.less"
  },
  {
    "revision": "de15d43dedc67cc2e8d9d237be5ef607",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/badges.less"
  },
  {
    "revision": "7dce9541e6a59de6301403a7d25036fa",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/breadcrumbs.less"
  },
  {
    "revision": "81b62a2061cb580b3a1b28af140b0251",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/bootstrap.less"
  },
  {
    "revision": "dab81ad5985687e444a3eedbdee9b15f",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/button-groups.less"
  },
  {
    "revision": "631abb68d682cf707930a490f8293f11",
    "url": "/fonts/weather-icons/svg/wi-train.svg"
  },
  {
    "revision": "c8402788b4a34b88f2eb20cf94c81a26",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/buttons.less"
  },
  {
    "revision": "c5b4a7b731d354a42573365b05504f23",
    "url": "/fonts/weather-icons/svg/wi-tornado.svg"
  },
  {
    "revision": "d6b62e1b2aeb1a17888f53e9af6ae4e9",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/alerts.less"
  },
  {
    "revision": "afbb12971867ecb12979c123eeb9925f",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/carousel.less"
  },
  {
    "revision": "4bc34218258348606259df6b1182e8e6",
    "url": "/fonts/weather-icons/_docs/jade/index.jade"
  },
  {
    "revision": "86f2f985b52f318877e43c37937a6f4e",
    "url": "/fonts/weather-icons/svg/wi-time-9.svg"
  },
  {
    "revision": "b174ef309d89c35893d3e2d38fe58719",
    "url": "/fonts/weather-icons/svg/wi-time-7.svg"
  },
  {
    "revision": "81ca3274627ca615962c237698f97f9e",
    "url": "/fonts/weather-icons/_docs/gh-pages/css/weather-icons.css"
  },
  {
    "revision": "556b77df941d48f44f1fb0d1fec61bc3",
    "url": "/fonts/weather-icons/_docs/gh-pages/css/weather-icons.min.css"
  },
  {
    "revision": "3b08f5c6009dbe5a17f2bfbacc6b8f2e",
    "url": "/fonts/weather-icons/_docs/gh-pages/api-list.html"
  },
  {
    "revision": "f8b3b3cf6698e225c1678c67ce4e6dff",
    "url": "/fonts/weather-icons/_docs/jade/api-list.jade"
  },
  {
    "revision": "144f8713038163a72b1ff67dfbc7f499",
    "url": "/fonts/weather-icons/svg/wi-time-8.svg"
  },
  {
    "revision": "d1106a9df41e0ef26a376551b5bbfd15",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/close.less"
  },
  {
    "revision": "6c5fe4b01404be6cfce4a211b0f03a99",
    "url": "/fonts/weather-icons/svg/wi-time-6.svg"
  },
  {
    "revision": "3c1f555d2382fdced70cfe1662631f71",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/code.less"
  },
  {
    "revision": "f7605695861c6f68a422d5fa9a936845",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/component-animations.less"
  },
  {
    "revision": "c27679fdc7a793f3ef833ad1136a957f",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/grid.less"
  },
  {
    "revision": "b6389a3f5cb24260af8e257d128b22d0",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/input-groups.less"
  },
  {
    "revision": "18e545cfb7385e21c753ba236824210a",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/labels.less"
  },
  {
    "revision": "e6b0c4c5ea7849594eeed6bb4487cb43",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/jumbotron.less"
  },
  {
    "revision": "91aa028d54785b36583c19020bba9f00",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/media.less"
  },
  {
    "revision": "78aa25760d223bf51d8d4edf59c2d384",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/alerts.less"
  },
  {
    "revision": "c0fdbbc84dd248331b77828eee0c1c40",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins.less"
  },
  {
    "revision": "0cdd3248330a2c7016ed24848d663abb",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/dropdowns.less"
  },
  {
    "revision": "30d64faff1cc98361fb1ec89b4e29418",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/border-radius.less"
  },
  {
    "revision": "308c38096591539f647ddf79fa92517c",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/buttons.less"
  },
  {
    "revision": "6781d24f5d2c3f947fe2b70ed9d53f77",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/list-group.less"
  },
  {
    "revision": "e2328a0e18978ca3f20412c36b014865",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/center-block.less"
  },
  {
    "revision": "8e9c9440f515f1586205aa595ae713ba",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/clearfix.less"
  },
  {
    "revision": "7f6754b3b31e2ad1272360e5a7d72124",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/gradients.less"
  },
  {
    "revision": "fd2eb11bccb993c98976fb5327227435",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/background-variant.less"
  },
  {
    "revision": "c093f97e58fe6d2de5714e40b5ab0e69",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/grid.less"
  },
  {
    "revision": "efb1d144197b84e10443192aec00a353",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/grid-framework.less"
  },
  {
    "revision": "0af48a82a48f4a2e0ae68afdc5295e5f",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/image.less"
  },
  {
    "revision": "92448ff5635fdcbe1322dd36929be43f",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/forms.less"
  },
  {
    "revision": "93df0c896c6224a0ae06207da241c14f",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/list-group.less"
  },
  {
    "revision": "840d6f9e7f5adcb066d6ca0d9ad02375",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/hide-text.less"
  },
  {
    "revision": "a9e830f1c39bd7e89679fe6ea200763c",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/nav-vertical-align.less"
  },
  {
    "revision": "b8d42af1e1ae77a37d1ac23e897d5761",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/pagination.less"
  },
  {
    "revision": "d3c6a97bacf167db12bb187f1ebc4a15",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/labels.less"
  },
  {
    "revision": "2d317d8386b126f6bd80a946e6c0ebf4",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/panels.less"
  },
  {
    "revision": "7039dc30596272eaf95604ce46532263",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/progress-bar.less"
  },
  {
    "revision": "ff42fe79f10deeaea892af691711fa33",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/reset-filter.less"
  },
  {
    "revision": "846f793e8d601915b31d2d7699bc35ab",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/nav-divider.less"
  },
  {
    "revision": "1cd48d78f06d33973d9d761d426e69bf",
    "url": "/fonts/weather-icons/_docs/gh-pages/font/weathericons-regular-webfont.woff2"
  },
  {
    "revision": "fc56fc793a8db0ac7742dcd653c10b99",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/reset-text.less"
  },
  {
    "revision": "b6ef275960e5f97b064c1aff7d6b3951",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/resize.less"
  },
  {
    "revision": "1be3f12daf02e4f36a4b7896b377c773",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/opacity.less"
  },
  {
    "revision": "cb591f72667a90bbc04e539332278019",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/size.less"
  },
  {
    "revision": "888e1e5f8e41a88aaa1afa58214b072e",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/tab-focus.less"
  },
  {
    "revision": "aa5d8a89db932a62dd90720c90e8e6e8",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/text-emphasis.less"
  },
  {
    "revision": "97f3e435fd0a2d7734213f94483a685e",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/text-overflow.less"
  },
  {
    "revision": "56a8bac1b9ddd3de170512d7e9269c1b",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/vendor-prefixes.less"
  },
  {
    "revision": "0523408a961e40e76f3808cad4658fe8",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/modals.less"
  },
  {
    "revision": "7061bdbd465d1cb633383dfa0f75fcc7",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/responsive-visibility.less"
  },
  {
    "revision": "3b3855aeeb76f7dd6868d68303d18a2e",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/mixins/table-row.less"
  },
  {
    "revision": "8a6cb19b0b4bd8e16c6b2aa5b834c184",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/navs.less"
  },
  {
    "revision": "ed5e06a70ad2f645989d687ecf4a4462",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/panels.less"
  },
  {
    "revision": "b70365e40424a2bffa41eaca9dfc99f8",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/pagination.less"
  },
  {
    "revision": "e4ba7eaa37b76f58f65cef48cbdcea52",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/pager.less"
  },
  {
    "revision": "b6fef93d5689af1a0467c8fc8e9959d9",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/print.less"
  },
  {
    "revision": "8aa5fae6c5138b6b9998d4e613645f4c",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/popovers.less"
  },
  {
    "revision": "a81f00910a701c842ede4f497c191c80",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/normalize.less"
  },
  {
    "revision": "2c7057d9a90998866bf84c1112caf631",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/responsive-embed.less"
  },
  {
    "revision": "2276b7244c5dc82454c4964bf2ed0c18",
    "url": "/fonts/weather-icons/svg/wi-time-5.svg"
  },
  {
    "revision": "b2bdb0de184055efe2c5d2280601a97c",
    "url": "/fonts/weather-icons/svg/wi-time-4.svg"
  },
  {
    "revision": "d7b2ce7636999c288435c6945afdab85",
    "url": "/fonts/weather-icons/svg/wi-time-3.svg"
  },
  {
    "revision": "c7fb834b69f1da031391b19695f117c0",
    "url": "/fonts/weather-icons/svg/wi-time-2.svg"
  },
  {
    "revision": "492077177889980e9ecefb4cfb2608d2",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/forms.less"
  },
  {
    "revision": "8a64c69dcfc081a7858285f1ab2992f5",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/responsive-utilities.less"
  },
  {
    "revision": "1a59f731ac07e06901f52546b230b62c",
    "url": "/fonts/weather-icons/_docs/font-source/weathericons-regular.otf"
  },
  {
    "revision": "6480c1133eeb09ad0154eb33edff35d8",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/tables.less"
  },
  {
    "revision": "2f0e86101267acacdd1466ea36044f3e",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/thumbnails.less"
  },
  {
    "revision": "8cac70ebda3f23ce472110d9f21e8593",
    "url": "/fonts/weather-icons/_docs/gh-pages/font/weathericons-regular-webfont.woff"
  },
  {
    "revision": "620d57934cdd4e984919a7d0e2bd7173",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/progress-bars.less"
  },
  {
    "revision": "829c59127f7339c17e803cae87017261",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/navbar.less"
  },
  {
    "revision": "746fc62c68f762055a26ecfa40ab655f",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/tooltip.less"
  },
  {
    "revision": "ddd239090feb6015f4b0478c3d0cc50f",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/type.less"
  },
  {
    "revision": "f8baac5bf438a29cc1b58328974049a9",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/utilities.less"
  },
  {
    "revision": "0eb21c0945a9fa86089de5c87bb34bf4",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/glyphicons.less"
  },
  {
    "revision": "3eb1f0e8352c03b9afac5f5008cd3afd",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/scaffolding.less"
  },
  {
    "revision": "91892051d6bb973c292f0822721e2409",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/theme.less"
  },
  {
    "revision": "4b5a84aaf1c9485e060c503a0ff8cadb",
    "url": "/fonts/weather-icons/_docs/gh-pages/fonts/fontawesome-webfont.woff2"
  },
  {
    "revision": "45c73723862c6fc5eb3d6961db2d71fb",
    "url": "/fonts/weather-icons/_docs/gh-pages/fonts/fontawesome-webfont.eot"
  },
  {
    "revision": "830f6e1a83f3a8c3244437d45c005f09",
    "url": "/fonts/weather-icons/_docs/less/cheatsheet.less"
  },
  {
    "revision": "496407c34cd52fab0c1ca1d17f0353a1",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/wells.less"
  },
  {
    "revision": "898f90e40876883214bbd121b0c20e9f",
    "url": "/fonts/weather-icons/_docs/less/font-awesome/bordered-pulled.less"
  },
  {
    "revision": "08baef05e05301cabc91599a54921081",
    "url": "/fonts/weather-icons/_docs/less/font-awesome/animated.less"
  },
  {
    "revision": "fb4efe4ae63737706875bbbfc7b7e9af",
    "url": "/fonts/weather-icons/_docs/less/font-awesome/core.less"
  },
  {
    "revision": "dfb02f8f6d0cedc009ee5887cc68f1f3",
    "url": "/fonts/weather-icons/_docs/gh-pages/fonts/fontawesome-webfont.woff"
  },
  {
    "revision": "ec5cb634bb671efba3cd1fae39450c47",
    "url": "/fonts/weather-icons/_docs/gh-pages/index.html"
  },
  {
    "revision": "5e07ec001f8d21bd279c12ee542813f7",
    "url": "/fonts/weather-icons/_docs/less/font-awesome/fixed-width.less"
  },
  {
    "revision": "8cb65280c0f889daf72626c21a7c8628",
    "url": "/fonts/weather-icons/_docs/less/font-awesome/larger.less"
  },
  {
    "revision": "4f6e61c4223f6a8192e93abca2a8a99c",
    "url": "/fonts/weather-icons/_docs/less/font-awesome/font-awesome.less"
  },
  {
    "revision": "975571323cf880a4a30601998236b027",
    "url": "/fonts/weather-icons/_docs/less/font-awesome/list.less"
  },
  {
    "revision": "a8476cdc50c264abd11ff59d6a9dd025",
    "url": "/fonts/weather-icons/_docs/less/font-awesome/rotated-flipped.less"
  },
  {
    "revision": "3ae443e0386cc3a69ff47d641aefb74b",
    "url": "/fonts/weather-icons/_docs/less/font-awesome/path.less"
  },
  {
    "revision": "518e2b2d263982d2caa1e6514b4b4eac",
    "url": "/fonts/weather-icons/_docs/less/font-awesome/stacked.less"
  },
  {
    "revision": "bfa7e97aa611d7f02e3be4e5aff9f5e2",
    "url": "/fonts/weather-icons/_docs/less/main.less"
  },
  {
    "revision": "707155cc30d441738f39b32e93d2bad3",
    "url": "/fonts/weather-icons/_docs/less/mixins.less"
  },
  {
    "revision": "137807d53dba2d42fa6118873ba2855c",
    "url": "/fonts/weather-icons/svg/wi-time-12.svg"
  },
  {
    "revision": "c2efba5e9b60fb70b2467a762e429a57",
    "url": "/fonts/weather-icons/svg/wi-time-11.svg"
  },
  {
    "revision": "93276985a7a6cc3053b98f243dd3e3bb",
    "url": "/fonts/weather-icons/_docs/less/variables.less"
  },
  {
    "revision": "63afa4054431cd255dd522314d42fe01",
    "url": "/fonts/weather-icons/_docs/less/font-awesome/mixins.less"
  },
  {
    "revision": "97a80fa50414fbae116430383cca0c86",
    "url": "/fonts/weather-icons/bower.json"
  },
  {
    "revision": "f5af981e104f3b879a8eebea5d16f917",
    "url": "/fonts/weather-icons/_docs/less/styles.less"
  },
  {
    "revision": "2e2511fda33377144b954ea0dae0b619",
    "url": "/fonts/weather-icons/less/icon-classes/classes-beaufort.less"
  },
  {
    "revision": "f75c7953352f076c51118897043ffaa2",
    "url": "/fonts/weather-icons/less/icon-classes/classes-day.less"
  },
  {
    "revision": "f266ead1b3d7399b1b9ea8ac05e476d4",
    "url": "/fonts/weather-icons/less/icon-classes/classes-direction.less"
  },
  {
    "revision": "0f70a430302abb28e70516ea3e383987",
    "url": "/fonts/weather-icons/less/icon-classes/classes-misc.less"
  },
  {
    "revision": "d6ade3a479afc43d7dd655355929b726",
    "url": "/fonts/weather-icons/less/icon-classes/classes-moon-aliases.less"
  },
  {
    "revision": "1362ca09ea19b240d461aae3519f0fee",
    "url": "/fonts/weather-icons/less/icon-classes/classes-moon.less"
  },
  {
    "revision": "8dbea1bdedead73a1df4212958fd7269",
    "url": "/fonts/weather-icons/less/icon-classes/classes-neutral.less"
  },
  {
    "revision": "1dd58f47aca505a6f2150f709e7a59a3",
    "url": "/fonts/weather-icons/less/icon-classes/classes-night.less"
  },
  {
    "revision": "e46fd90ae82a46f9d097a2550a269731",
    "url": "/fonts/weather-icons/less/icon-classes/classes-wind-aliases.less"
  },
  {
    "revision": "3ac70d579fa3a1edf4163ebb4de2a9b9",
    "url": "/fonts/weather-icons/less/icon-classes/classes-time.less"
  },
  {
    "revision": "39d8cba69c1ee7f7ce94b7cd68f7400f",
    "url": "/fonts/weather-icons/less/icon-classes/classes-wind.less"
  },
  {
    "revision": "e76ac7a26f6ad33e42695ddeb64a69b0",
    "url": "/fonts/weather-icons/less/icon-variables/variables-day.less"
  },
  {
    "revision": "eac30c3b0d3a5e842396dd41ac7e815c",
    "url": "/fonts/weather-icons/less/icon-variables/variables-direction.less"
  },
  {
    "revision": "f56d456cec6e9a5a8a793888d8195996",
    "url": "/fonts/weather-icons/less/icon-variables/variables-moon.less"
  },
  {
    "revision": "1b48ded46aa1884019fe4c3a892faee6",
    "url": "/fonts/weather-icons/less/icon-variables/variables-misc.less"
  },
  {
    "revision": "23ee922cf0c478faaa71c9a33a8afd03",
    "url": "/fonts/weather-icons/less/icon-variables/variables-beaufort.less"
  },
  {
    "revision": "f7e053097aa9c6ddffc3553385959ece",
    "url": "/fonts/weather-icons/less/icon-variables/variables-neutral.less"
  },
  {
    "revision": "59cc94f37f4c8014b999fc7b8689dc32",
    "url": "/fonts/weather-icons/less/icon-variables/variables-wind-names.less"
  },
  {
    "revision": "71258238267ff3a73e5097995141f383",
    "url": "/fonts/weather-icons/less/icon-variables/variables-time.less"
  },
  {
    "revision": "a1abe9735315aece9cda5eeb4c6f1fec",
    "url": "/fonts/weather-icons/less/mappings/wi-forecast-io.less"
  },
  {
    "revision": "85183dfa8030c8a33b87298c661cc861",
    "url": "/fonts/weather-icons/less/mappings/wi-wunderground.less"
  },
  {
    "revision": "93cf9ba8f0e96ffb314044ebc7b02d59",
    "url": "/fonts/weather-icons/less/mappings/wi-yahoo.less"
  },
  {
    "revision": "a16c3ce0fdcb061f06fc7b9d11609969",
    "url": "/fonts/weather-icons/less/weather-icons-classes.less"
  },
  {
    "revision": "d1ee284afdeef00c68633b7e866f4a53",
    "url": "/fonts/weather-icons/less/icon-variables/variables-night.less"
  },
  {
    "revision": "5aec8d9b9816e6e80779e28297213468",
    "url": "/fonts/weather-icons/less/mappings/wi-wmo4680.less"
  },
  {
    "revision": "d6e5162ac46d342da8ac427bea5792df",
    "url": "/fonts/weather-icons/less/weather-icons-core.less"
  },
  {
    "revision": "0076df872a4bb979cdba594d191d0cce",
    "url": "/fonts/weather-icons/less/weather-icons-variables.less"
  },
  {
    "revision": "b336f3a722f51e432ce40dbb5353fff4",
    "url": "/fonts/weather-icons/less/weather-icons-wind.less"
  },
  {
    "revision": "53220d5cd1e3bdefa24c54b5806a85d4",
    "url": "/fonts/weather-icons/_docs/less/bootstrap/variables.less"
  },
  {
    "revision": "4ea9810fbc6d32449433f0143936d1d6",
    "url": "/fonts/weather-icons/less/weather-icons.less"
  },
  {
    "revision": "228c88c66f2ffbf2aa15b994895f1df1",
    "url": "/fonts/weather-icons/less/weather-icons.min.less"
  },
  {
    "revision": "b336f3a722f51e432ce40dbb5353fff4",
    "url": "/fonts/weather-icons/less/weather-icons-wind.min.less"
  },
  {
    "revision": "5bdc94592f4bb8180854afab1ef963ff",
    "url": "/fonts/weather-icons/package.json"
  },
  {
    "revision": "d410c4280f8bdeb9d9cff86723c1f1be",
    "url": "/fonts/weather-icons/sass/icon-classes/classes-beaufort.scss"
  },
  {
    "revision": "a0eacea9d241f1724bc79a04adb80061",
    "url": "/fonts/weather-icons/svg/wi-time-10.svg"
  },
  {
    "revision": "d0b99b09e07743441699de4f52a6967c",
    "url": "/fonts/weather-icons/sass/icon-classes/classes-day.scss"
  },
  {
    "revision": "c023ad74055343ec463780280d4bd4c5",
    "url": "/fonts/weather-icons/sass/icon-classes/classes-direction.scss"
  },
  {
    "revision": "7e6d45ecc86655dcfe473055ce195291",
    "url": "/fonts/weather-icons/sass/icon-classes/classes-misc.scss"
  },
  {
    "revision": "ef5e8f9cbd09753078629e041a941588",
    "url": "/fonts/weather-icons/sass/icon-classes/classes-moon-aliases.scss"
  },
  {
    "revision": "ffe2025ea7ffcbf0f14d30d5f22698e6",
    "url": "/fonts/weather-icons/sass/icon-classes/classes-moon.scss"
  },
  {
    "revision": "5cab0dc3f0d67dbfc4196bf68f0f0d02",
    "url": "/fonts/weather-icons/sass/icon-classes/classes-neutral.scss"
  },
  {
    "revision": "96deacae046c32ee7f4d9e0567a0484b",
    "url": "/fonts/weather-icons/_docs/less/font-awesome/variables.less"
  },
  {
    "revision": "7ac0c09166b728b7fcfc2beb00a9eeb4",
    "url": "/fonts/weather-icons/sass/icon-classes/classes-night.scss"
  },
  {
    "revision": "4b658767da6bd92ce2addb3ce512784d",
    "url": "/fonts/weather-icons/_docs/gh-pages/font/weathericons-regular-webfont.eot"
  },
  {
    "revision": "6df90ee6f49d2d5a3f49f8f091994042",
    "url": "/fonts/weather-icons/sass/icon-classes/classes-time.scss"
  },
  {
    "revision": "4618f0de2a818e7ad3fe880e0b74d04a",
    "url": "/fonts/weather-icons/_docs/gh-pages/font/weathericons-regular-webfont.ttf"
  },
  {
    "revision": "668743fe7258676f8ef8f9b47d2a623e",
    "url": "/fonts/weather-icons/_docs/gh-pages/fonts/FontAwesome.otf"
  },
  {
    "revision": "a207eaf67d03250472e4f813bf2112e1",
    "url": "/fonts/weather-icons/sass/icon-classes/classes-wind-aliases.scss"
  },
  {
    "revision": "7fc975da19637b266a5ad43152933edb",
    "url": "/fonts/weather-icons/less/mappings/wi-owm.less"
  },
  {
    "revision": "09adc880765c78db46ff753598d4bbec",
    "url": "/fonts/weather-icons/css/weather-icons.css"
  },
  {
    "revision": "556b77df941d48f44f1fb0d1fec61bc3",
    "url": "/fonts/weather-icons/css/weather-icons.min.css"
  },
  {
    "revision": "b5fd391db0b3db12dbf33ad3dafcbf07",
    "url": "/fonts/weather-icons/sass/icon-classes/classes-wind.scss"
  },
  {
    "revision": "3ac345194b88087189fa75446aeb2948",
    "url": "/fonts/weather-icons/less/icon-classes/classes-wind-degrees.less"
  },
  {
    "revision": "afcf33deb0883dc82c16ba83874d216c",
    "url": "/fonts/weather-icons/svg/wi-time-1.svg"
  },
  {
    "revision": "00affcba61cf67ad85ee2d86f2152396",
    "url": "/fonts/weather-icons/sass/icon-variables/variables-beaufort.scss"
  },
  {
    "revision": "0c8a68e36c259819acae5c0377cb73e4",
    "url": "/fonts/weather-icons/sass/icon-variables/variables-day.scss"
  },
  {
    "revision": "244e805f77eafbe8ee6afa44dc07f3cb",
    "url": "/fonts/weather-icons/sass/icon-variables/variables-direction.scss"
  },
  {
    "revision": "a03da7160c5b860cc2adaa83c98c063a",
    "url": "/fonts/weather-icons/sass/icon-variables/variables-misc.scss"
  },
  {
    "revision": "a432434c19b35c8419821a01a463f958",
    "url": "/fonts/weather-icons/sass/icon-variables/variables-moon.scss"
  },
  {
    "revision": "a543bad53536b54ad5c5bd05a9ece3d6",
    "url": "/fonts/weather-icons/sass/icon-variables/variables-neutral.scss"
  },
  {
    "revision": "298232ed24e8992970817a1e1cc61db8",
    "url": "/fonts/weather-icons/sass/icon-variables/variables-night.scss"
  },
  {
    "revision": "9fb2cd638a706a5ee93eb7df723326fe",
    "url": "/fonts/weather-icons/sass/icon-variables/variables-time.scss"
  },
  {
    "revision": "e6fe3b4dd15172925a4a705dd665a971",
    "url": "/fonts/weather-icons/_docs/less/font-awesome/icons.less"
  },
  {
    "revision": "58cb8d42f23fee5684b8d8e7be36f8ea",
    "url": "/fonts/weather-icons/sass/icon-variables/variables-wind-names.scss"
  },
  {
    "revision": "8e3046021b3911778e14361f9861b018",
    "url": "/fonts/weather-icons/sass/mappings/wi-forecast-io.scss"
  },
  {
    "revision": "64d8a891d6d9b60ecce6f985b094b2da",
    "url": "/fonts/weather-icons/sass/mappings/wi-wmo4680.scss"
  },
  {
    "revision": "e271106326f045a22f52d0694f014ac7",
    "url": "/fonts/weather-icons/sass/mappings/wi-wunderground.scss"
  },
  {
    "revision": "837171e7760221f33656d526c24c5b10",
    "url": "/fonts/weather-icons/sass/mappings/wi-yahoo.scss"
  },
  {
    "revision": "743210bf69cecaf9487d9208264d48d4",
    "url": "/fonts/weather-icons/sass/weather-icons-classes.scss"
  },
  {
    "revision": "c662e04da148d1b194bb7cc5671cabca",
    "url": "/fonts/weather-icons/sass/weather-icons-core.scss"
  },
  {
    "revision": "83edbd9d8bc258175832f94d90fee15f",
    "url": "/fonts/weather-icons/sass/weather-icons-variables.scss"
  },
  {
    "revision": "ea89df70968584e0e6a04f88c1435dcb",
    "url": "/fonts/weather-icons/sass/weather-icons-wind.min.scss"
  },
  {
    "revision": "ea89df70968584e0e6a04f88c1435dcb",
    "url": "/fonts/weather-icons/sass/weather-icons-wind.scss"
  },
  {
    "revision": "9e257855b7777b19645c63225f9acb72",
    "url": "/fonts/weather-icons/_docs/gh-pages/css/weather-icons-wind.min.css"
  },
  {
    "revision": "3b2618b6de33bfba7448a8f13400e6ba",
    "url": "/fonts/weather-icons/sass/weather-icons.min.scss"
  },
  {
    "revision": "1dfd66b9fb42c18365f3",
    "url": "/js/about.1e862edd.js"
  },
  {
    "revision": "1cd48d78f06d33973d9d761d426e69bf",
    "url": "/fonts/weather-icons/font/weathericons-regular-webfont.woff2"
  },
  {
    "revision": "531b634c40d3d6ee87c1c37e09865ba9",
    "url": "/fonts/weather-icons/svg/wi-alien.svg"
  },
  {
    "revision": "997436c237683fc2617358b62e3b2c56",
    "url": "/fonts/weather-icons/svg/wi-barometer.svg"
  },
  {
    "revision": "2d5fb94096f6a0dd48d00cd8e1566d33",
    "url": "/fonts/weather-icons/svg/wi-celsius.svg"
  },
  {
    "revision": "e10599402af02fe88dd4eaae79fdc72b",
    "url": "/fonts/weather-icons/svg/wi-cloud-down.svg"
  },
  {
    "revision": "19b10c5f271b055225c7ee56382d71d4",
    "url": "/fonts/weather-icons/svg/wi-cloud-refresh.svg"
  },
  {
    "revision": "c6d57c766b493ba838b5be906bdf4b18",
    "url": "/fonts/weather-icons/svg/wi-cloud-up.svg"
  },
  {
    "revision": "82408b66052f4d1c4ebe7376ad490c8b",
    "url": "/fonts/weather-icons/svg/wi-cloud.svg"
  },
  {
    "revision": "8f977e0c609cf550b7cce9bb0b90bd42",
    "url": "/fonts/weather-icons/svg/wi-cloudy-gusts.svg"
  },
  {
    "revision": "988749e88d71465ce6f62f4ed707bf2c",
    "url": "/fonts/weather-icons/svg/wi-cloudy-windy.svg"
  },
  {
    "revision": "2d0410c52e9fe2b3e0fb905f129ad19a",
    "url": "/fonts/weather-icons/svg/wi-cloudy.svg"
  },
  {
    "revision": "28859f6519239eead587ad8051b632f5",
    "url": "/fonts/weather-icons/svg/wi-day-cloudy-gusts.svg"
  },
  {
    "revision": "60f84c71fabfbc84348d04fdc83a47a0",
    "url": "/fonts/weather-icons/svg/wi-day-cloudy-high.svg"
  },
  {
    "revision": "3237f7da426fbedf7faa6782f8c4c455",
    "url": "/fonts/weather-icons/svg/wi-day-cloudy.svg"
  },
  {
    "revision": "307f87845d9095288733a2b6b2e6b37a",
    "url": "/fonts/weather-icons/svg/wi-day-hail.svg"
  },
  {
    "revision": "493be2a811d011aaac110a81defcd374",
    "url": "/fonts/weather-icons/svg/wi-day-fog.svg"
  },
  {
    "revision": "8dfc3bc5a7395bc0877043b102a852f3",
    "url": "/fonts/weather-icons/svg/wi-day-cloudy-windy.svg"
  },
  {
    "revision": "cd4506ada6c25813a38c2668d724271a",
    "url": "/fonts/weather-icons/svg/wi-day-haze.svg"
  },
  {
    "revision": "746b40a81dda99faccfec37677be3114",
    "url": "/fonts/weather-icons/svg/wi-day-light-wind.svg"
  },
  {
    "revision": "42698e359a19c767f0a6f41e1defb902",
    "url": "/fonts/weather-icons/svg/wi-day-lightning.svg"
  },
  {
    "revision": "ea0763d6c92254adb443e6c14740ca38",
    "url": "/fonts/weather-icons/svg/wi-day-rain-mix.svg"
  },
  {
    "revision": "52c484ed757d77ed5693f997c4f1cb0b",
    "url": "/fonts/weather-icons/svg/wi-day-rain-wind.svg"
  },
  {
    "revision": "ac93e407f620ec5eee663939681d518f",
    "url": "/fonts/weather-icons/svg/wi-day-rain.svg"
  },
  {
    "revision": "86f986fca5306e37fe323f0b8b7cc389",
    "url": "/fonts/weather-icons/svg/wi-day-showers.svg"
  },
  {
    "revision": "f45eece5fd4f0a91695fe6928be5e2d5",
    "url": "/fonts/weather-icons/svg/wi-day-sleet.svg"
  },
  {
    "revision": "9b85f535a6945f6a48b379ecdac23ea3",
    "url": "/fonts/weather-icons/svg/wi-day-sleet-storm.svg"
  },
  {
    "revision": "203aa99134d9de86a1bc926829351978",
    "url": "/fonts/weather-icons/svg/wi-day-snow-thunderstorm.svg"
  },
  {
    "revision": "04cc1b6db8e66dd8830db8fe00d00491",
    "url": "/fonts/weather-icons/svg/wi-day-snow-wind.svg"
  },
  {
    "revision": "0437c5fe50f97b1f696b135b8736f58a",
    "url": "/fonts/weather-icons/svg/wi-day-snow.svg"
  },
  {
    "revision": "83ad8e0b67ba1d2333f49fd84cade17f",
    "url": "/fonts/weather-icons/svg/wi-day-sprinkle.svg"
  },
  {
    "revision": "8cac70ebda3f23ce472110d9f21e8593",
    "url": "/fonts/weather-icons/font/weathericons-regular-webfont.woff"
  },
  {
    "revision": "686b9678b224f1fe8a857409cea065b8",
    "url": "/fonts/weather-icons/svg/wi-day-storm-showers.svg"
  },
  {
    "revision": "92905ca491a3ace1e36a512242b4dc14",
    "url": "/fonts/weather-icons/svg/wi-day-sunny-overcast.svg"
  },
  {
    "revision": "4b9869a6859846e524d1985de86894f7",
    "url": "/fonts/weather-icons/svg/wi-day-sunny.svg"
  },
  {
    "revision": "a1ec88df52249ece1a6bc37e8eebe1bd",
    "url": "/fonts/weather-icons/svg/wi-day-thunderstorm.svg"
  },
  {
    "revision": "7c87870ab40d63cfb8870c1f183f9939",
    "url": "/fonts/weather-icons/_docs/gh-pages/fonts/fontawesome-webfont.ttf"
  },
  {
    "revision": "5653ab64d1d6844752d6d0ebdbbea019",
    "url": "/fonts/weather-icons/svg/wi-day-windy.svg"
  },
  {
    "revision": "3c3cc3b2d4cf8336605578002e6f797e",
    "url": "/fonts/weather-icons/svg/wi-degrees.svg"
  },
  {
    "revision": "4eb23b5a1795eae3c07586b7fc935108",
    "url": "/fonts/weather-icons/svg/wi-direction-down-left.svg"
  },
  {
    "revision": "758caacb5e2fc99f9fc4c673e404309d",
    "url": "/fonts/weather-icons/svg/wi-direction-down-right.svg"
  },
  {
    "revision": "22fff390b0fcd9c46390fe913b23895d",
    "url": "/fonts/weather-icons/svg/wi-thunderstorm.svg"
  },
  {
    "revision": "9872bcc4037fd576c11e30836dd49c78",
    "url": "/fonts/weather-icons/svg/wi-direction-down.svg"
  },
  {
    "revision": "24e49e257194e282863970afea2e1300",
    "url": "/fonts/weather-icons/svg/wi-thermometer.svg"
  },
  {
    "revision": "541ab229782db51195fa72c7e570b61c",
    "url": "/fonts/weather-icons/svg/wi-direction-left.svg"
  },
  {
    "revision": "3bdab7aec1dd55e3d2d61a2d97c269b4",
    "url": "/fonts/weather-icons/svg/wi-direction-right.svg"
  },
  {
    "revision": "1a38ebdce4156abff08f51cf4d8bf1ef",
    "url": "/fonts/weather-icons/sass/mappings/wi-owm.scss"
  },
  {
    "revision": "255f6df34b1ab36a5745d7ac744c9f57",
    "url": "/fonts/weather-icons/svg/wi-direction-up-left.svg"
  },
  {
    "revision": "cbd11a695ae0e2a6e8567018003cc36b",
    "url": "/fonts/weather-icons/svg/wi-direction-up-right.svg"
  },
  {
    "revision": "71f1d75a36bb080f8c39929815533e53",
    "url": "/fonts/weather-icons/_docs/gh-pages/css/weather-icons-wind.css"
  },
  {
    "revision": "784874dface6e56e3bf637d05d675fe3",
    "url": "/fonts/weather-icons/svg/wi-direction-up.svg"
  },
  {
    "revision": "d66e1eebede09874d16cd86e7c35d57d",
    "url": "/fonts/weather-icons/svg/wi-dust.svg"
  },
  {
    "revision": "ab3c230b847f5f9f068aae51b691c273",
    "url": "/fonts/weather-icons/svg/wi-earthquake.svg"
  },
  {
    "revision": "66b095cf95b64ef9d853b2815cd92354",
    "url": "/fonts/weather-icons/svg/wi-fahrenheit.svg"
  },
  {
    "revision": "587913b3386dcbb32a41b896bdd789f3",
    "url": "/fonts/weather-icons/sass/icon-classes/classes-wind-degrees.scss"
  },
  {
    "revision": "6268a47ef2e95d73bc1e45dadfdf5a1a",
    "url": "/fonts/weather-icons/svg/wi-fire.svg"
  },
  {
    "revision": "a263997d94b152f298a6575660f897da",
    "url": "/fonts/weather-icons/svg/wi-flood.svg"
  },
  {
    "revision": "c356784f45aaa40ef57ed9031101d912",
    "url": "/fonts/weather-icons/svg/wi-fog.svg"
  },
  {
    "revision": "7bc33419ab629480052f195049f897c5",
    "url": "/fonts/weather-icons/svg/wi-gale-warning.svg"
  },
  {
    "revision": "a4598f7699558fa2a8201690bd673fc4",
    "url": "/fonts/weather-icons/svg/wi-hail.svg"
  },
  {
    "revision": "c02360f87e7e372b20564d0387dc3cc3",
    "url": "/fonts/weather-icons/svg/wi-horizon-alt.svg"
  },
  {
    "revision": "7da71f4c576c7914581248d67205b269",
    "url": "/fonts/weather-icons/svg/wi-horizon.svg"
  },
  {
    "revision": "1057600879741c7acd7e2982a96c990c",
    "url": "/fonts/weather-icons/svg/wi-hot.svg"
  },
  {
    "revision": "ace478e89dad3f20c96b3532b123cfdc",
    "url": "/fonts/weather-icons/svg/wi-humidity.svg"
  },
  {
    "revision": "7a67f74716d278d680c3752d344886e0",
    "url": "/fonts/weather-icons/svg/wi-hurricane-warning.svg"
  },
  {
    "revision": "dcb4ac8744c261c45422dd67e46a65bf",
    "url": "/fonts/weather-icons/svg/wi-hurricane.svg"
  },
  {
    "revision": "be8364b31b4ff5c5b9f4c624d982dd98",
    "url": "/fonts/weather-icons/svg/wi-lightning.svg"
  },
  {
    "revision": "82da2b9d23e84d73d1fcacd6abe6fcfc",
    "url": "/fonts/weather-icons/svg/wi-lunar-eclipse.svg"
  },
  {
    "revision": "2e40242004e7b077aeba0a24a49e79b7",
    "url": "/fonts/weather-icons/svg/wi-meteor.svg"
  },
  {
    "revision": "6c7323bcb51469aca39b873df64d2995",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-first-quarter.svg"
  },
  {
    "revision": "00bd422b9134608a30a14c2f9591c03c",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-full.svg"
  },
  {
    "revision": "e2bd0eb053dd9ba3e13691839cdfdfe9",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-new.svg"
  },
  {
    "revision": "052c33f8eac8ec6b3dff1bcecc31ab43",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-third-quarter.svg"
  },
  {
    "revision": "3a1ae04c628723b956553045442644ae",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waning-crescent-1.svg"
  },
  {
    "revision": "9135182cea9751f2a02f8793b8f654eb",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waning-crescent-2.svg"
  },
  {
    "revision": "c0af4998a8957bcac0d75140bfa98023",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waning-crescent-3.svg"
  },
  {
    "revision": "f8a92b76e53f677d20ad7bbe5b3da35b",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waning-crescent-4.svg"
  },
  {
    "revision": "dbba3edc243c3297a1a95c18c95d64e5",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waning-crescent-5.svg"
  },
  {
    "revision": "d11167a379262d098bcace6f37f19148",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waning-crescent-6.svg"
  },
  {
    "revision": "23603eab5ea8da28093566993c79417a",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waning-gibbous-1.svg"
  },
  {
    "revision": "0c6b57640224b3b5d68ab5f7b0ea778f",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waning-gibbous-2.svg"
  },
  {
    "revision": "4f46eea906f5233d33b9a4fcd5ee77fe",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waning-gibbous-3.svg"
  },
  {
    "revision": "6c8c04bec9292150ae209e5a12dedafe",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waning-gibbous-4.svg"
  },
  {
    "revision": "d6a1f57efb462428413a59b7ee8e8712",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waning-gibbous-5.svg"
  },
  {
    "revision": "c4f7014f316c489b5389718158d84a75",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waning-gibbous-6.svg"
  },
  {
    "revision": "3ce871de04c7f33a2954621b5e665738",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waxing-crescent-1.svg"
  },
  {
    "revision": "1d52a3a0a9bbd29e059c3c54def57f4d",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waxing-crescent-2.svg"
  },
  {
    "revision": "aca423e56d39033ef58ca270ceb0a8c2",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waxing-crescent-3.svg"
  },
  {
    "revision": "215ec14cf5e02a6cc38352df152d21b2",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waxing-crescent-4.svg"
  },
  {
    "revision": "2b2409473cf8934ace545e80aa1d22ab",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waxing-crescent-5.svg"
  },
  {
    "revision": "0e83bad2ce4d8cb681cdee0b315854e7",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waxing-crescent-6 .svg"
  },
  {
    "revision": "2822bad28151d2b838e41bf6f20634b3",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waxing-gibbous-1.svg"
  },
  {
    "revision": "b27b9ecc0ff3b3f9c205fa33d688635a",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waxing-gibbous-2.svg"
  },
  {
    "revision": "101f770df9266106054392db0e883e1f",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waxing-gibbous-3.svg"
  },
  {
    "revision": "afea03377f4cfc9afdd02ef21b02bcb1",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waxing-gibbous-4.svg"
  },
  {
    "revision": "1bbe75956b9a5677c035bf275a6c76e2",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waxing-gibbous-5.svg"
  },
  {
    "revision": "0aea7499a63197043c78cccc512528f6",
    "url": "/fonts/weather-icons/svg/wi-moon-alt-waxing-gibbous-6 .svg"
  },
  {
    "revision": "e2bd0eb053dd9ba3e13691839cdfdfe9",
    "url": "/fonts/weather-icons/svg/wi-moon-full.svg"
  },
  {
    "revision": "67c1fdf38da6ad68a5de6698fdb54684",
    "url": "/fonts/weather-icons/svg/wi-moon-first-quarter.svg"
  },
  {
    "revision": "00bd422b9134608a30a14c2f9591c03c",
    "url": "/fonts/weather-icons/svg/wi-moon-new.svg"
  },
  {
    "revision": "8c4adbb02aba4e94c02d762bb85a27ac",
    "url": "/fonts/weather-icons/svg/wi-moon-third-quarter.svg"
  },
  {
    "revision": "3641a7a0833058a48e4a16d13172ac91",
    "url": "/fonts/weather-icons/svg/wi-moon-waning-crescent-1.svg"
  },
  {
    "revision": "585bcf211ec06d578fad0f91ee79bdd7",
    "url": "/fonts/weather-icons/svg/wi-moon-waning-crescent-2.svg"
  },
  {
    "revision": "94f28050a506b22cb4bf0dd6e6aa60fc",
    "url": "/fonts/weather-icons/svg/wi-moon-waning-crescent-3.svg"
  },
  {
    "revision": "55e9a0a8e6cc58a50e3bd98fc23b26bc",
    "url": "/fonts/weather-icons/svg/wi-moon-waning-crescent-4 .svg"
  },
  {
    "revision": "71cd7ab84e972c9f4a5f4bba0db34916",
    "url": "/fonts/weather-icons/svg/wi-moon-waning-crescent-5.svg"
  },
  {
    "revision": "d5335d4adead7c3af5f65eefef276ddd",
    "url": "/fonts/weather-icons/svg/wi-moon-waning-crescent-6.svg"
  },
  {
    "revision": "2cffc20333428487dd54693119c85eb0",
    "url": "/fonts/weather-icons/svg/wi-moon-waning-gibbous-1.svg"
  },
  {
    "revision": "36a2a067be11b34e80d06f4ac74fb114",
    "url": "/fonts/weather-icons/svg/wi-moon-waning-gibbous-2.svg"
  },
  {
    "revision": "fdeed6f24f22b6268a08730aa4b3ce13",
    "url": "/fonts/weather-icons/svg/wi-moon-waning-gibbous-3.svg"
  },
  {
    "revision": "ca57970a71eb1fff29c0a536646907eb",
    "url": "/fonts/weather-icons/svg/wi-moon-waning-gibbous-4.svg"
  },
  {
    "revision": "373b8266ea8ed89d032d3a642bb97253",
    "url": "/fonts/weather-icons/svg/wi-moon-waning-gibbous-5 .svg"
  },
  {
    "revision": "2a6194de04711079ecba72ed8380ceeb",
    "url": "/fonts/weather-icons/svg/wi-moon-waning-gibbous-6.svg"
  },
  {
    "revision": "6a17d1525a409fa0e4750676d4a136ea",
    "url": "/fonts/weather-icons/svg/wi-moon-waxing-crescent-1.svg"
  },
  {
    "revision": "71cca0fee45490eaecbe66786d454ada",
    "url": "/fonts/weather-icons/svg/wi-moon-waxing-crescent-2.svg"
  },
  {
    "revision": "fd643dfef080e1d435af8b4c1e65c03c",
    "url": "/fonts/weather-icons/svg/wi-moon-waxing-crescent-3.svg"
  },
  {
    "revision": "86a428721dfa903cdcf9bb0ac07938b4",
    "url": "/fonts/weather-icons/svg/wi-moon-waxing-crescent-4.svg"
  },
  {
    "revision": "b648bf895a6ef6b24d7dc5338bfc72c7",
    "url": "/fonts/weather-icons/svg/wi-moon-waxing-crescent-5.svg"
  },
  {
    "revision": "b648bf895a6ef6b24d7dc5338bfc72c7",
    "url": "/fonts/weather-icons/svg/wi-moon-waxing-crescent-6 .svg"
  },
  {
    "revision": "88d11cd876070176437d235b5de193f8",
    "url": "/fonts/weather-icons/svg/wi-moon-waxing-gibbous-1.svg"
  },
  {
    "revision": "183da817d15e143789778d93317d835e",
    "url": "/fonts/weather-icons/svg/wi-moon-waxing-gibbous-2.svg"
  },
  {
    "revision": "0544157bdafe1dd0313bec2b1078e281",
    "url": "/fonts/weather-icons/svg/wi-moon-waxing-gibbous-3.svg"
  },
  {
    "revision": "a597394511f0bda7e0f148db8e20f6ad",
    "url": "/fonts/weather-icons/svg/wi-moon-waxing-gibbous-4 .svg"
  },
  {
    "revision": "1b91ef0f9add73846fcdc576379a5591",
    "url": "/fonts/weather-icons/svg/wi-moon-waxing-gibbous-5.svg"
  },
  {
    "revision": "3b9f7d10d765d4990705bbfd81213641",
    "url": "/fonts/weather-icons/svg/wi-moon-waxing-gibbous-6.svg"
  },
  {
    "revision": "5e6841e2a95e0ef829c3106c7960b623",
    "url": "/fonts/weather-icons/svg/wi-moonrise.svg"
  },
  {
    "revision": "18f91498cc6f98e8ad98856485913343",
    "url": "/fonts/weather-icons/svg/wi-moonset.svg"
  },
  {
    "revision": "fd90aeab153084786ebff365b91f3419",
    "url": "/fonts/weather-icons/svg/wi-na.svg"
  },
  {
    "revision": "fc2e7bc82223c21365213a2b484db569",
    "url": "/fonts/weather-icons/svg/wi-night-alt-cloudy-gusts.svg"
  },
  {
    "revision": "2fdaa36bd6fc3af59ed530f163255ed7",
    "url": "/fonts/weather-icons/svg/wi-night-alt-cloudy-high.svg"
  },
  {
    "revision": "07db20d635cfde98563cdb06f7b54edc",
    "url": "/fonts/weather-icons/svg/wi-night-alt-cloudy-windy.svg"
  },
  {
    "revision": "7c36f2b5180391599389cc38849eb89d",
    "url": "/fonts/weather-icons/svg/wi-night-alt-cloudy.svg"
  },
  {
    "revision": "1c9558261632ac23cefb746918f3facf",
    "url": "/fonts/weather-icons/svg/wi-night-alt-hail.svg"
  },
  {
    "revision": "4b658767da6bd92ce2addb3ce512784d",
    "url": "/fonts/weather-icons/font/weathericons-regular-webfont.eot"
  },
  {
    "revision": "54f0fa3b6cbee9d4a60e89bb20a21306",
    "url": "/fonts/weather-icons/_docs/gh-pages/css/styles.css"
  },
  {
    "revision": "b9ee5038892977ce6930f8e489956150",
    "url": "/fonts/weather-icons/svg/wi-night-alt-lightning.svg"
  },
  {
    "revision": "4618f0de2a818e7ad3fe880e0b74d04a",
    "url": "/fonts/weather-icons/font/weathericons-regular-webfont.ttf"
  },
  {
    "revision": "ecaf8b481729b18f6a8494d9f691cdae",
    "url": "/fonts/weather-icons/_docs/gh-pages/font/weathericons-regular-webfont.svg"
  },
  {
    "revision": "b75d90bdda7e56b0435b10a36d87392e",
    "url": "/fonts/weather-icons/svg/wi-night-alt-partly-cloudy.svg"
  },
  {
    "revision": "79e70b3659ec800424ccdec617ef299f",
    "url": "/fonts/weather-icons/svg/wi-night-alt-rain-mix.svg"
  },
  {
    "revision": "6dfa13419e87616d93bfce49f058f3eb",
    "url": "/fonts/weather-icons/svg/wi-night-alt-rain-wind.svg"
  },
  {
    "revision": "bc016c3b72a5843f21623b98e9c90f3d",
    "url": "/fonts/weather-icons/svg/wi-night-alt-rain.svg"
  },
  {
    "revision": "8ea1ac4e4686afcd6d32776a8c6879e7",
    "url": "/fonts/weather-icons/svg/wi-night-alt-showers.svg"
  },
  {
    "revision": "3bf07524cf1ca030776a4ff21f522840",
    "url": "/fonts/weather-icons/svg/wi-night-alt-sleet-storm.svg"
  },
  {
    "revision": "0bda2fbb706e331c898eb3baa59fc8fb",
    "url": "/fonts/weather-icons/svg/wi-night-alt-sleet.svg"
  },
  {
    "revision": "a9e0233f71dfbf0f5b7978ee53a97b49",
    "url": "/fonts/weather-icons/svg/wi-night-alt-snow-thunderstorm.svg"
  },
  {
    "revision": "77e6d8969dfd81a2c277cd12b04b159d",
    "url": "/fonts/weather-icons/svg/wi-night-alt-snow-wind.svg"
  },
  {
    "revision": "db72088b07bc32e7beee32cc8408f26f",
    "url": "/fonts/weather-icons/svg/wi-night-alt-snow.svg"
  },
  {
    "revision": "136e99617edae7b63187401a54471df2",
    "url": "/fonts/weather-icons/svg/wi-night-alt-sprinkle.svg"
  },
  {
    "revision": "83f2607826e2c0f225a02066db19ace1",
    "url": "/fonts/weather-icons/svg/wi-night-alt-storm-showers.svg"
  },
  {
    "revision": "f86c33c4ccc36dbeb826cbdb5f50594b",
    "url": "/fonts/weather-icons/svg/wi-night-clear.svg"
  },
  {
    "revision": "8a97fabc4397460de410f5127c339cdb",
    "url": "/fonts/weather-icons/svg/wi-night-alt-thunderstorm.svg"
  },
  {
    "revision": "907c20a58f724e68f924397449c6eede",
    "url": "/fonts/weather-icons/svg/wi-night-cloudy-gusts.svg"
  },
  {
    "revision": "cf7f17dac346daa146d5303b681ab40f",
    "url": "/fonts/weather-icons/svg/wi-night-cloudy-high.svg"
  },
  {
    "revision": "527741fa50e7ab1d1bc887e4f9aeeadf",
    "url": "/fonts/weather-icons/svg/wi-night-cloudy-windy.svg"
  },
  {
    "revision": "abda2f646ad5c3ece93e4db304e86b10",
    "url": "/fonts/weather-icons/svg/wi-night-cloudy.svg"
  },
  {
    "revision": "7f68f0ff6f6536dd9cb27be521b2881d",
    "url": "/fonts/weather-icons/svg/wi-night-fog.svg"
  },
  {
    "revision": "130262db9db479b674c60b9a47816179",
    "url": "/fonts/weather-icons/svg/wi-night-lightning.svg"
  },
  {
    "revision": "cdc48240d1570cbc07e845fdaa56048b",
    "url": "/fonts/weather-icons/svg/wi-night-hail.svg"
  },
  {
    "revision": "567c9bd7fe5de02ebc0129e851b2b105",
    "url": "/fonts/weather-icons/svg/wi-night-partly-cloudy.svg"
  },
  {
    "revision": "1d0aa7dbca627d4a062c96a14b3efd54",
    "url": "/fonts/weather-icons/svg/wi-night-rain-mix.svg"
  },
  {
    "revision": "3957d00e62000e9b42eb6c281df1422c",
    "url": "/fonts/weather-icons/svg/wi-night-rain-wind.svg"
  },
  {
    "revision": "b0c6ff5d9328fd9e6f7359283c91d2be",
    "url": "/fonts/weather-icons/svg/wi-night-rain.svg"
  },
  {
    "revision": "c65f0bf35c13e1d9c03fc1bc1b085ba8",
    "url": "/fonts/weather-icons/svg/wi-night-sleet-storm.svg"
  },
  {
    "revision": "e65996e37ba9c9fa105049d6d3b0c29c",
    "url": "/fonts/weather-icons/svg/wi-night-showers.svg"
  },
  {
    "revision": "57c7fe43edbb263a64d638f35a0f0ad9",
    "url": "/fonts/weather-icons/svg/wi-night-sleet.svg"
  },
  {
    "revision": "df31aa073ab927f05c9b911511dfc283",
    "url": "/fonts/weather-icons/svg/wi-night-snow-thunderstorm.svg"
  },
  {
    "revision": "9e257855b7777b19645c63225f9acb72",
    "url": "/fonts/weather-icons/css/weather-icons-wind.min.css"
  },
  {
    "revision": "87bc0271f7a30df74ee5990f1d39d708",
    "url": "/fonts/weather-icons/svg/wi-night-snow-wind.svg"
  },
  {
    "revision": "bdaa4c8d3f7c6349d3aa61837083debc",
    "url": "/fonts/weather-icons/svg/wi-night-snow.svg"
  },
  {
    "revision": "729719bc0754fbd1e093288e49934365",
    "url": "/fonts/weather-icons/svg/wi-night-sprinkle.svg"
  },
  {
    "revision": "21225e304c25be2cd2a43474ac2e7b9d",
    "url": "/fonts/weather-icons/svg/wi-night-storm-showers.svg"
  },
  {
    "revision": "d44a5fdcf9c938ec91348518c015f41c",
    "url": "/fonts/weather-icons/svg/wi-night-thunderstorm.svg"
  },
  {
    "revision": "67c5e2561147500e2dcfaa34b6903b66",
    "url": "/fonts/weather-icons/svg/wi-rain-mix.svg"
  },
  {
    "revision": "4635f2772c90baecda1e760bbd67f91e",
    "url": "/fonts/weather-icons/svg/wi-rain-wind.svg"
  },
  {
    "revision": "e13be320202dc94ef0d3696c1f508d24",
    "url": "/fonts/weather-icons/svg/wi-rain.svg"
  },
  {
    "revision": "5ac590b7c142c7d4205c502edecf748c",
    "url": "/fonts/weather-icons/svg/wi-raindrop.svg"
  },
  {
    "revision": "45d30c621cddd753486f07b636f7a8d0",
    "url": "/fonts/weather-icons/svg/wi-raindrops.svg"
  },
  {
    "revision": "6b5be906701b5e8666c9104dbbd60251",
    "url": "/fonts/weather-icons/svg/wi-refresh-alt.svg"
  },
  {
    "revision": "ae069e32a4a683727ca4a51b27d72108",
    "url": "/fonts/weather-icons/svg/wi-refresh.svg"
  },
  {
    "revision": "631f7b8dff9ff6ec9aa2a968aa664765",
    "url": "/fonts/weather-icons/svg/wi-sandstorm.svg"
  },
  {
    "revision": "751f534517c6cb83b1c7ec78fd32786d",
    "url": "/fonts/weather-icons/svg/wi-showers.svg"
  },
  {
    "revision": "8291f3539cf9ca67ea3680a1a4a720f5",
    "url": "/fonts/weather-icons/svg/wi-sleet.svg"
  },
  {
    "revision": "5106f61daad94d020fec3e706d85c220",
    "url": "/fonts/weather-icons/svg/wi-small-craft-advisory.svg"
  },
  {
    "revision": "042cd80fef694e39263228e8c5e627f8",
    "url": "/fonts/weather-icons/svg/wi-smog.svg"
  },
  {
    "revision": "1325271128c1f81a2695f3619434888a",
    "url": "/fonts/weather-icons/svg/wi-smoke.svg"
  },
  {
    "revision": "0434333c0751afceef49f28c6fccea91",
    "url": "/fonts/weather-icons/svg/wi-snow-wind.svg"
  },
  {
    "revision": "1a2bbf7db1720db83324bbf482344ec4",
    "url": "/fonts/weather-icons/svg/wi-snow.svg"
  },
  {
    "revision": "10a793ebc6338f2b279727fd2de81308",
    "url": "/fonts/weather-icons/svg/wi-snowflake-cold.svg"
  },
  {
    "revision": "98ca3860e8a739d4e9c2a6cefaec6e04",
    "url": "/fonts/weather-icons/svg/wi-solar-eclipse.svg"
  },
  {
    "revision": "36a19f5b73a3d68d6fc8b480a9714bea",
    "url": "/fonts/weather-icons/svg/wi-sprinkle.svg"
  },
  {
    "revision": "36217d383b037311dd2e627cb88506d8",
    "url": "/fonts/weather-icons/svg/wi-stars.svg"
  },
  {
    "revision": "64d9af100ecccd48a7c29f9d781b1ef6",
    "url": "/fonts/weather-icons/svg/wi-storm-showers.svg"
  },
  {
    "revision": "a3fae3f4aebcc77204dc53ef4ed47216",
    "url": "/fonts/weather-icons/svg/wi-storm-warning.svg"
  },
  {
    "revision": "1968dadd1e36e188133385f7662681d0",
    "url": "/fonts/weather-icons/svg/wi-thermometer-internal.svg"
  },
  {
    "revision": "b9d8d3cf851d2253ea0f306c860c5812",
    "url": "/fonts/weather-icons/svg/wi-strong-wind.svg"
  },
  {
    "revision": "11f9daa177005434b7579ac59fe246f4",
    "url": "/fonts/weather-icons/svg/wi-sunrise.svg"
  },
  {
    "revision": "d96e94d55441191c134f7bb19690785c",
    "url": "/fonts/weather-icons/svg/wi-sunset.svg"
  },
  {
    "revision": "9a23179e56c86ac0a6ab929d3baae9e0",
    "url": "/fonts/weather-icons/svg/wi-thermometer-exterior.svg"
  },
  {
    "revision": "0bf5b42a815f1d563dd0e30ceecf6b0b",
    "url": "/fonts/weather-icons/_builder/day.edn"
  },
  {
    "revision": "ebb8719a0c817798a5dad7fdfd4ebbca",
    "url": "/fonts/MontserratAlternates-Regular.ttf"
  },
  {
    "revision": "7ec5dab7e7ff250971d2ff50379778dc",
    "url": "/fonts/materialdesignicons-webfont.7ec5dab7.woff2"
  },
  {
    "revision": "a0d13d16cc2f3647680d9f1ff003f58b",
    "url": "/fonts/materialdesignicons-webfont.a0d13d16.woff"
  },
  {
    "revision": "9b5dc3b7086d1a0419b670a914c60d12",
    "url": "/fonts/weather-icons/README.md"
  },
  {
    "revision": "e2654feaf3f5657cbcb62ece33a9442d",
    "url": "/fonts/weather-icons/.npmignore"
  },
  {
    "revision": "75fde39fd91c85f3c5113e4efb354eb5",
    "url": "/fonts/weather-icons/.gitignore"
  },
  {
    "revision": "e88ec18827526928e71407a24937825a",
    "url": "/fonts/Product Sans Italic.ttf"
  },
  {
    "revision": "dba0c688b8d5ee09a1e214aebd5d25e4",
    "url": "/fonts/Product Sans Bold.ttf"
  },
  {
    "revision": "79750b1d82b2558801373d62dd7e5280",
    "url": "/fonts/Product Sans Bold Italic.ttf"
  },
  {
    "revision": "3ac50b5b36eb2f11b000dce1792d0bb0",
    "url": "/fonts/materialdesignicons-webfont.3ac50b5b.ttf"
  },
  {
    "revision": "eae9c18cee82a8a1a52e654911f8fe83",
    "url": "/fonts/Product Sans Regular.ttf"
  },
  {
    "revision": "a32fa1f27abbfa96ff2f79e1ade723d5",
    "url": "/fonts/materialdesignicons-webfont.a32fa1f2.eot"
  },
  {
    "revision": "4520ddfc56208707045c56232e946f7f",
    "url": "/fonts/photo.jpg"
  },
  {
    "revision": "938b3999f44adf366c84bcec48752195",
    "url": "/fonts/google-product-sans.jpg"
  },
  {
    "revision": "47982767f24beacef402e903e63f40f9",
    "url": "/fonts/weather-icons/_builder/csv/wind-degrees.csv"
  },
  {
    "revision": "cbde6c886cd57a3c641f56fc4c594f0f",
    "url": "/fonts/weather-icons/_builder/beaufort.edn"
  },
  {
    "revision": "1b8f4f86d54a09da286549b1faf6fb01",
    "url": "/fonts/weather-icons/_builder/time.edn"
  },
  {
    "revision": "6cfbb1193a16bb73dc989a62d82d4389",
    "url": "/fonts/weather-icons/_builder/templates.edn"
  },
  {
    "revision": "69bedac4b6f317a112fbd743251864f1",
    "url": "/fonts/weather-icons/_builder/night.edn"
  },
  {
    "revision": "f592d7c1030525576a65042be76a3361",
    "url": "/fonts/weather-icons/_builder/neutral.edn"
  },
  {
    "revision": "08f5860bf479361626e7f9566f16f79c",
    "url": "/fonts/weather-icons/_builder/moon.edn"
  },
  {
    "revision": "2660bb8401df29fea450599b50708c58",
    "url": "/fonts/weather-icons/_builder/misc.edn"
  },
  {
    "revision": "ccf7ebf658bad13478621537bc17f304",
    "url": "/fonts/weather-icons/_builder/direction.edn"
  },
  {
    "revision": "980a2107e29add2b359481ee2c3821bc",
    "url": "/fonts/weather-icons/_builder/csv/bak.csv"
  },
  {
    "revision": "3a6177d602edd326914b19d976279fe1",
    "url": "/fonts/weather-icons/_builder/csv/wind.csv"
  },
  {
    "revision": "5ffca0f0cea1b370b5b6e9ecbd457dd3",
    "url": "/fonts/demo.html"
  },
  {
    "revision": "b8b354a0d666d8ed62ea336715ac448e",
    "url": "/fonts/weather-icons/_builder/csv/time.csv"
  },
  {
    "revision": "d41d8cd98f00b204e9800998ecf8427e",
    "url": "/fonts/weather-icons/_builder/csv/temp.csv"
  },
  {
    "revision": "93eeb23eeceda16182320e0eee4e9576",
    "url": "/fonts/weather-icons/_builder/csv/night.csv"
  },
  {
    "revision": "08fe3ffbeeb06de0eeda2ef6643fff53",
    "url": "/fonts/weather-icons/_builder/csv/neutral.csv"
  },
  {
    "revision": "38447642af9a40fa2d6cc38e9f4736b7",
    "url": "/fonts/weather-icons/_builder/csv/moon.csv"
  },
  {
    "revision": "d5532d010cc3d5a80c69e1a698d4c3c2",
    "url": "/fonts/weather-icons/_builder/csv/misc.csv"
  },
  {
    "revision": "bbffeea117d61369c16d6cb2f4a11b1d",
    "url": "/fonts/opengraph_color_1200dp.png"
  },
  {
    "revision": "7e0c994bc81cf423a52ca08380df9bd1",
    "url": "/fonts/weather-icons/_builder/csv/direction.csv"
  },
  {
    "revision": "b2746a477126683b00842b2a3e716f6e",
    "url": "/fonts/weather-icons/_builder/csv/day.csv"
  },
  {
    "revision": "8106aee708aebb272ee5e50a98dd45a7",
    "url": "/fonts/weather-icons/_builder/csv/beaufort.csv"
  },
  {
    "revision": "3c703404ced5f2dc97c1bd1193d88ef0",
    "url": "/fonts/Montserrat-Regular.woff"
  },
  {
    "revision": "7d03680a899b35f87b69b178541204a4",
    "url": "/fonts/Montserrat-Regular.ttf"
  },
  {
    "revision": "3ee93f9d4c9b3b319d5f12cbe5d69729",
    "url": "/fonts/Montserrat-Regular.wxss"
  },
  {
    "revision": "5a22b18982148217f735f7f8909d6903",
    "url": "/fonts/Montserrat-Regular.woff2"
  },
  {
    "revision": "85023695c0ceb0649cd8775e552b7a7b",
    "url": "/fonts/Montserrat-Regular.svg"
  },
  {
    "revision": "51b34cac63ce7d52778b9deb9499c699",
    "url": "/fonts/Montserrat-Regular.eot"
  },
  {
    "revision": "96a17babd446f1f007a6ab37ac45c7e5",
    "url": "/css/smartxs.css"
  },
  {
    "revision": "a9bd613d677f1e509e1f57c42705f901",
    "url": "/css/holakit.css"
  },
  {
    "revision": "eb7e3877bf99d7a7d607",
    "url": "/css/chunk-vendors.4ab025e8.css"
  },
  {
    "revision": "50a51685f7fd398d5cbe",
    "url": "/css/app.595b80ce.css"
  },
  {
    "revision": "1dfd66b9fb42c18365f3",
    "url": "/css/about.45fac905.css"
  }
];